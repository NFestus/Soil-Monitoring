import os
import django
import random
import time
from datetime import datetime

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "smart_irrigation.settings")
django.setup()

from irrigation.models import SoilSensor, SensorReading

SENSOR_NAMES = [
    "Sensor A", "Sensor B", "Sensor C", "Sensor D", "Sensor E",
    "Sensor F", "Sensor G", "Sensor H", "Sensor I", "Sensor J",
    "Sensor K", "Sensor L", "Sensor M", "Sensor N", "Sensor O",
    "Sensor P", "Sensor Q", "Sensor R", "Sensor S", "Sensor T"
]

LOCATIONS = ["Kigali", "Rubavu", "Rusizi", "Ruhango", "Muhanga", "Bugesera", "Rwamagana"]

CROP_TYPES = [
    "Wheat", "Corn", "Rice", "Soybean", "Cotton",
    "Barley", "Oats", "Sorghum", "Millet", "Sugarcane"
]

SOIL_TYPES = ["Sandy Soil", "Silty Soil","Clay Soil","Loamy Soil"]

STATUSES = ['active', 'inactive', 'faulty']

def create_sensors_if_none():
    if SoilSensor.objects.count() == 0:
        print("No sensors found. Creating 20 sensors...")
        for name in SENSOR_NAMES:
            sensor = SoilSensor.objects.create(
                name=name,
                location=random.choice(LOCATIONS),
                soil_type=random.choice(SOIL_TYPES),
                crop_type=random.choice(CROP_TYPES),
                soil_moisture=0,
                sensor_status='active'
            )
            print(f"Created sensor: {sensor.name}, Location: {sensor.location}, Soil: {sensor.soil_type}, Crop: {sensor.crop_type}")

def simulate_data():
    create_sensors_if_none()
    while True:
        sensors = SoilSensor.objects.all()
        for sensor in sensors:
            new_moisture = round(random.uniform(10, 80), 2)
            SensorReading.objects.create(
                sensor=sensor,
                moisture_measurements=new_moisture
            )
            # Update ONLY moisture and status; do NOT update name, location, soil_type, crop_type
            sensor.soil_moisture = new_moisture
            sensor.sensor_status = random.choice(STATUSES)
            sensor.save()

            print(f"[{datetime.now()}] Sensor '{sensor.name}' updated: "
                  f"Moisture={new_moisture}%, Status={sensor.sensor_status}")

        time.sleep(5)

if __name__ == "__main__":
    simulate_data()
