from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    # Django admin
    path('admin/', admin.site.urls),
    
    # API routes from sensors app
    path('', include('irrigation.urls')),  
    
    # Dashboard page (HTML template)
    path('dashboard/', TemplateView.as_view(template_name='dashboard.html'), name='dashboard'),
]
