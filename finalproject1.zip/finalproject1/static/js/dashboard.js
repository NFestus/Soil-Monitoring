const API_URL = '/api/dashboard_data/';

// DOM elements
const totalSensorsElem = document.getElementById('totalSensors');
const activeSensorsElem = document.getElementById('activeSensors');
const avgMoistureElem = document.getElementById('avgMoisture');
const alertCountElem = document.getElementById('alertCount');
const lastUpdatedElem = document.getElementById('lastUpdated');
const periodButtons = document.querySelectorAll('.btn-period');

let selectedPeriod = '1h'; // Default period
let moistureChart = null;

// Initialize the line chart
function initChart() {
  const ctx = document.getElementById('moistureChart').getContext('2d');
  moistureChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Soil Moisture (%)',
        data: [],
        borderColor: 'rgba(54, 162, 235, 1)',
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        fill: true,
        tension: 0.3,
        pointRadius: 3,
        pointHoverRadius: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 0 // Disable animation for smoother updates
      },
      scales: {
        y: {
          min: 0,
          max: 100,
          ticks: {
            stepSize: 10,
            callback: function(value) {
              return value + '%';
            }
          },
          title: {
            display: true,
            text: 'Moisture (%)',
          }
        },
        x: {
          title: {
            display: true,
            text: 'Time',
          },
          ticks: {
            maxRotation: 45,
            minRotation: 45,
            maxTicksLimit: 10,
          }
        }
      },
      plugins: {
        legend: { 
          display: true 
        },
        tooltip: { 
          mode: 'index', 
          intersect: false 
        },
      },
      interaction: {
        intersect: false,
        mode: 'index'
      }
    }
  });
}

// Update chart data
function updateChartData(readings) {
  if (!moistureChart || !readings || readings.length === 0) {
    if (moistureChart) {
      moistureChart.data.labels = [];
      moistureChart.data.datasets[0].data = [];
      moistureChart.update();
    }
    return;
  }

  // Format timestamps for display
  const labels = readings.map(reading => {
    const date = new Date(reading.timestamp);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  });

  const moistureData = readings.map(reading => reading.moisture);

  moistureChart.data.labels = labels;
  moistureChart.data.datasets[0].data = moistureData;
  moistureChart.update();
}

// Update statistics display
function updateStats(data) {
  if (totalSensorsElem) totalSensorsElem.textContent = data.total_sensors || 0;
  if (activeSensorsElem) activeSensorsElem.textContent = data.active_sensors || 0;
  if (avgMoistureElem) avgMoistureElem.textContent = (data.avg_moisture || 0) + '%';
  if (alertCountElem) alertCountElem.textContent = data.alerts || 0;
  if (lastUpdatedElem) lastUpdatedElem.textContent = new Date().toLocaleTimeString();
}

// Fetch dashboard data from API
async function fetchDashboardData(period) {
  try {
    const url = new URL(API_URL, window.location.origin);
    url.searchParams.append('period', period);

    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();

    // Update statistics
    updateStats(data);

    // Update chart
    updateChartData(data.readings);

    console.log('Dashboard updated successfully', data);

  } catch (error) {
    console.error('Failed to fetch dashboard data:', error);
    
    // Show error in UI
    if (lastUpdatedElem) {
      lastUpdatedElem.textContent = 'Error loading data';
      lastUpdatedElem.className = 'badge bg-danger';
    }
  }
}

// Initialize chart and set up event listeners
document.addEventListener('DOMContentLoaded', function() {
  // Initialize the chart
  initChart();

  // Set up period selector buttons
  periodButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      // Remove active class from all buttons
      periodButtons.forEach(b => b.classList.remove('active'));
      
      // Add active class to clicked button
      btn.classList.add('active');
      
      // Update selected period
      selectedPeriod = btn.getAttribute('data-period');
      
      // Fetch new data
      fetchDashboardData(selectedPeriod);
    });
  });

  // Set initial active button
  const initialButton = document.querySelector(`.btn-period[data-period="${selectedPeriod}"]`);
  if (initialButton) {
    initialButton.classList.add('active');
  }

  // Initial data fetch
  fetchDashboardData(selectedPeriod);

  // Set up polling interval (every 5 seconds)
  setInterval(() => {
    fetchDashboardData(selectedPeriod);
  }, 5000);
});