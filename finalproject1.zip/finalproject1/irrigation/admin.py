from django.contrib import admin
from .models import SoilSensor, SensorReading, IrrigationLog

admin.site.register(SoilSensor)
admin.site.register(SensorReading)
admin.site.register(IrrigationLog)
