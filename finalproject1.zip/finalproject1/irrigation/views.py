from django.http import JsonResponse
from django.utils import timezone
from datetime import timedelta
from irrigation.models import SoilSensor, SensorReading
from rest_framework import viewsets
from .models import SoilSensor, SensorReading, IrrigationLog
from .serializers import SoilSensorSerializer, SensorReadingSerializer, IrrigationLogSerializer
from django.db import models
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.db.models import Avg
from django.db.models.functions import TruncHour, TruncMinute, TruncDay

class SoilSensorViewSet(viewsets.ModelViewSet):
    queryset = SoilSensor.objects.all()
    serializer_class = SoilSensorSerializer

class SensorReadingViewSet(viewsets.ModelViewSet):
    queryset = SensorReading.objects.all()
    serializer_class = SensorReadingSerializer

class IrrigationLogViewSet(viewsets.ModelViewSet):
    queryset = IrrigationLog.objects.all()
    serializer_class = IrrigationLogSerializer

def get_time_range(period):
    """Helper function to get time range based on period parameter"""
    now = timezone.now()

    # Handle seconds-based intervals
    if period.endswith('s'):
        seconds = int(period.replace('s', ''))
        start_time = now - timedelta(seconds=seconds)
    elif period == '1min':
        start_time = now - timedelta(minutes=1)
    elif period == '5min':
        start_time = now - timedelta(minutes=5)
    elif period == '15min':
        start_time = now - timedelta(minutes=15)
    elif period == '30min':
        start_time = now - timedelta(minutes=30)
    elif period == '1h':
        start_time = now - timedelta(hours=1)
    elif period == '6h':
        start_time = now - timedelta(hours=6)
    elif period == '24h':
        start_time = now - timedelta(hours=24)
    elif period == '7d':
        start_time = now - timedelta(days=7)
    elif period == '30d':
        start_time = now - timedelta(days=30)
    else:
        start_time = now - timedelta(minutes=5)  # default
    
    return start_time, now

def dashboard_data(request):
    """Enhanced dashboard data with detailed sensor status breakdown"""
    period = request.GET.get('period', '5min')  # Default to 5min for live stats
    start_time, now = get_time_range(period)

    readings = SensorReading.objects.filter(timestamp__gte=start_time).order_by('timestamp')

    # Get all sensors and their current status
    all_sensors = SoilSensor.objects.all()
    total_sensors = all_sensors.count()
    active_sensors = all_sensors.filter(sensor_status='active').count()
    faulty_sensors = all_sensors.filter(sensor_status='faulty').count()
    
    # Calculate inactive sensors (assuming sensors can be 'active', 'faulty', or 'inactive')
    inactive_sensors = all_sensors.filter(sensor_status='inactive').count()
    
    # If you don't have explicit 'inactive' status, calculate it:
    # inactive_sensors = total_sensors - active_sensors - faulty_sensors

    data = []
    for reading in readings:
        data.append({
            'sensor': reading.sensor.name,
            'timestamp': reading.timestamp.isoformat(),
            'moisture': reading.moisture_measurements,
            'status': reading.sensor.sensor_status,
        })

    response = {
        'readings': data,
        'total_sensors': total_sensors,
        'active_sensors': active_sensors,
        'inactive_sensors': inactive_sensors,  # Added inactive sensors
        'faulty_sensors': faulty_sensors,      # Renamed from 'alerts' to be more clear
        'alerts': faulty_sensors,              # Keep for backward compatibility
        'avg_moisture': round(readings.aggregate(avg=models.Avg('moisture_measurements'))['avg'] or 0, 2),
        'period': period,
        'last_updated': now.isoformat(),
    }
    return JsonResponse(response)

@api_view(['GET'])
def sensor_moisture_summary(request):
    period = request.GET.get('period', '5min')  # now supports seconds
    start_time, now = get_time_range(period)

    summary = (
        SensorReading.objects.filter(timestamp__range=(start_time, now))
        .values('sensor__name')
        .annotate(average_moisture=Avg('moisture_measurements'))
        .order_by('sensor__name')
    )

    data = [
        {
            'sensor_name': item['sensor__name'],
            'average_moisture': round(item['average_moisture'], 2) if item['average_moisture'] else 0,
            'period': period,
            'calculated_at': now.isoformat()
        }
        for item in summary
    ]

    return Response(data)


@api_view(['GET'])
def moisture_trend_data(request):
    """
    Returns time-series data for trend line showing system-wide moisture averages
    with sensor information for each time point
    """
    period = request.GET.get('period', '1h')
    start_time, now = get_time_range(period)

    # Determine time format based on period
    if period in ['1min', '5min', '15min', '30min', '1h']:
        time_format = '%H:%M'
    elif period == '6h':
        time_format = '%H:%M'
    elif period == '24h':
        time_format = '%H:%M'
    elif period == '7d':
        time_format = '%m/%d %H:%M'
    else:  # 30d
        time_format = '%m/%d'

    # Get all readings in the time range with sensor information
    readings = SensorReading.objects.filter(
        timestamp__range=(start_time, now)
    ).select_related('sensor').order_by('timestamp')

    # Group readings manually based on period
    trend_data = []
    
    if not readings.exists():
        # Return empty data if no readings
        trend_data = [{
            'timestamp': now.strftime(time_format),
            'avg_moisture': 0,
            'sensors': [],
            'sensor_count': 0
        }]
    else:
        # Group readings by time intervals
        grouped_readings = {}
        
        for reading in readings:
            # Create time buckets based on period
            if period == '1min':
                # 10-second buckets
                bucket_seconds = (reading.timestamp.second // 10) * 10
                bucket_time = reading.timestamp.replace(second=bucket_seconds, microsecond=0)
            elif period == '5min':
                # 30-second buckets
                bucket_seconds = (reading.timestamp.second // 30) * 30
                bucket_time = reading.timestamp.replace(second=bucket_seconds, microsecond=0)
            elif period == '15min':
                # 1-minute buckets
                bucket_time = reading.timestamp.replace(second=0, microsecond=0)
            elif period == '30min':
                # 2-minute buckets
                bucket_minutes = (reading.timestamp.minute // 2) * 2
                bucket_time = reading.timestamp.replace(minute=bucket_minutes, second=0, microsecond=0)
            elif period == '1h':
                # 5-minute buckets
                bucket_minutes = (reading.timestamp.minute // 5) * 5
                bucket_time = reading.timestamp.replace(minute=bucket_minutes, second=0, microsecond=0)
            elif period == '6h':
                # 15-minute buckets  
                bucket_minutes = (reading.timestamp.minute // 15) * 15
                bucket_time = reading.timestamp.replace(minute=bucket_minutes, second=0, microsecond=0)
            elif period == '24h':
                # 1-hour buckets
                bucket_time = reading.timestamp.replace(minute=0, second=0, microsecond=0)
            elif period == '7d':
                # 4-hour buckets
                bucket_hours = (reading.timestamp.hour // 4) * 4
                bucket_time = reading.timestamp.replace(hour=bucket_hours, minute=0, second=0, microsecond=0)
            else:  # 30d
                # Daily buckets
                bucket_time = reading.timestamp.replace(hour=0, minute=0, second=0, microsecond=0)
            
            bucket_key = bucket_time.strftime(time_format)
            
            if bucket_key not in grouped_readings:
                grouped_readings[bucket_key] = {
                    'moisture_values': [],
                    'sensors': set()
                }
            
            grouped_readings[bucket_key]['moisture_values'].append(reading.moisture_measurements)
            grouped_readings[bucket_key]['sensors'].add(reading.sensor.name)
        
        # Calculate averages and sensor info for each bucket
        for timestamp_str, data in sorted(grouped_readings.items()):
            if data['moisture_values']:  # Only include buckets with data
                avg_moisture = sum(data['moisture_values']) / len(data['moisture_values'])
                trend_data.append({
                    'timestamp': timestamp_str,
                    'avg_moisture': round(avg_moisture, 2),
                    'sensors': sorted(list(data['sensors'])),  # Convert set to sorted list
                    'sensor_count': len(data['sensors'])
                })

    return Response({
        'trend_data': trend_data,
        'period': period,
        'total_points': len(trend_data)
    })

@api_view(['GET'])
def individual_sensor_data(request):
    """
    Returns individual sensor moisture readings over time
    """
    sensor_name = request.GET.get('sensor', '')
    period = request.GET.get('period', '1h')
    start_time, now = get_time_range(period)

    # Get sensor readings
    try:
        sensor = SoilSensor.objects.get(name=sensor_name)
        readings = SensorReading.objects.filter(
            sensor=sensor,
            timestamp__range=(start_time, now)
        ).order_by('timestamp')
        
        # Format readings for frontend
        reading_data = []
        for reading in readings:
            reading_data.append({
                'timestamp': reading.timestamp.isoformat(),
                'moisture': reading.moisture_measurements,
                'sensor_status': reading.sensor.sensor_status
            })

        return Response({
            'sensor_name': sensor_name,
            'sensor_status': sensor.sensor_status,
            'readings': reading_data,
            'period': period,
            'data_points': len(reading_data),
            'latest_reading': reading_data[-1] if reading_data else None
        })

    except SoilSensor.DoesNotExist:
        return Response({
            'error': f'Sensor "{sensor_name}" not found',
            'sensor_name': sensor_name,
            'readings': [],
            'period': period,
            'data_points': 0
        }, status=404)