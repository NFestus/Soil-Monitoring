from rest_framework import serializers
from .models import SoilSensor, SensorReading, IrrigationLog

class SoilSensorSerializer(serializers.ModelSerializer):
    class Meta:
        model = SoilSensor
        fields = '__all__'

class SensorReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorReading
        fields = '__all__'

class IrrigationLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = IrrigationLog
        fields = '__all__'
