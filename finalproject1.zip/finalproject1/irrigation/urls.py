#urls.py
from django.urls import path, include
from rest_framework import routers
from .views import (
    SoilSensorViewSet,
    SensorReadingViewSet,
    IrrigationLogViewSet,
    dashboard_data,
    sensor_moisture_summary, 
    moisture_trend_data,
    individual_sensor_data,
    
)

router = routers.DefaultRouter()
router.register(r'soil_sensors', SoilSensorViewSet)
router.register(r'sensor_readings', SensorReadingViewSet)
router.register(r'irrigation_logs', IrrigationLogViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
    path('api/dashboard_data/', dashboard_data, name='dashboard_data'),
    path('api/sensor_moisture_summary/', sensor_moisture_summary, name='sensor_moisture_summary'),  
    # Add this to your urlpatterns
    path('api/moisture_trend_data/',moisture_trend_data, name='moisture_trend_data'),
    path('api/individual_sensor_data/',individual_sensor_data, name='individual_sensor_data'),
]
