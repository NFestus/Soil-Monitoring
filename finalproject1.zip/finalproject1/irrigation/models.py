from django.db import models

class SoilSensor(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=200)
    soil_type = models.CharField(max_length=100)
    crop_type = models.CharField(max_length=100)
    soil_moisture = models.FloatField()
    sensor_status = models.CharField(max_length=50, choices=[
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('faulty', 'Faulty')
    ])

    def __str__(self):
        return self.name


class SensorReading(models.Model):
    sensor = models.ForeignKey(SoilSensor, on_delete=models.CASCADE, related_name="readings")
    moisture_measurements = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)


class IrrigationLog(models.Model):
    sensor = models.ForeignKey(SoilSensor, on_delete=models.CASCADE, related_name="irrigations")
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    moisture_before_irr = models.FloatField()
    moisture_after_irr = models.FloatField()
